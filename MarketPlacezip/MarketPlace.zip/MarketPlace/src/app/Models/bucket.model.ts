export interface Bucket{
    id:number;
    name:string;
    quantity:number
}