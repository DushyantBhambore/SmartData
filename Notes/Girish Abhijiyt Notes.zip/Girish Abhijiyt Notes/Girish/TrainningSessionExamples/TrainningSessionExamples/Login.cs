﻿namespace TrainningSessionExamples
{

    public class Login
    {
        public string Name { get; set; }
        public string Password { get; set; }
    }

    public class Tokens
    {
        public string Token { get; set; }
        public string RefreshToken { get; set; }
    }
}
