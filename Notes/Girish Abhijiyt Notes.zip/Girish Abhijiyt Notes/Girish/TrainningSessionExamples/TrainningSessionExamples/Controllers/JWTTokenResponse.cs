﻿namespace TrainningSessionExamples.Controllers
{
    internal class JWTTokenResponse
    {
        public string Token { get; set; }
    }
}