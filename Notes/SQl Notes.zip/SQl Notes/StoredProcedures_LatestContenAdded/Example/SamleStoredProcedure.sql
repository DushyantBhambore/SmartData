/*
Title:			spDisplayWelcome
Creator:		ABC

Purpose: 		
Functionality:	
Created:		
Applications:	

Comments:		
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Example:		

                    EXECUTE spDisplayWelcome

                    EXEC    spDisplayWelcome

                            spDisplayWelcome


Output:		
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Return Values:	
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Modifications:

Date          Developer        Description
----------  --------------	--------------------------------------------------------------------------------------------------------------------
00/00/0000   ABC              sdsdsdsdsd
*/


CREATE PROCEDURE spDisplayWelcome
AS
BEGIN
  PRINT 'WELCOME TO PROCEDURE in SQL Server'
END
